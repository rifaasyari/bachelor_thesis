function [s_estim] = mb_lr_sic(y, H, signal_power, N, modulation, ... 
    constellation, use_clll)
% MB_LR_SIC Implements the "Mutli-Branch Lattice Reduction Successive
% Interference Cancellation Detection for Multiuser MIMO Systems" [1]
%
%   Input
%       y: Received signal 
%       H: Channel gain matrix
%       signal_power: Power of transmitted signals
%       N: Noise power
%       modulation (string): Used modulation: "QPSK" or "16-QAM"
%       constellation (matrix):
%       use_clll (bool): If true apply CLLL reduction to H.
%           Otherwise this function performs *MB-SIC* detection
%   
%   Output
%       s_estim: Estimation of transmitted signal
%
%   [1]: L. Arvelo, R. Lamare, K. Zu, R. Sampaio-Neto, "Multi-Branch
%       Lattice Reduction Successive Interference Cancellation Detection 
%       for Multiuser MIMO Systems", 11th International Symposium on
%       Wireless Communication Systems, Barcelona, Spain, 2014, pp. 219 - 
%       223
%
%   See also CLLL, CNBO, PSP, MMSE_FILTER, SHIFTING_SCALING, ML_MIMO
    
    if nargin == 6
        use_clll = true;
    end
    
    N_t = size(H, 2);  % Total number of transmit antennas is equal to 
                       % number of columns in H
    L = N_t;  % Number of permutations of channel gain matrix H
    
    if use_clll
        [H_LR, T] = clll(H, 0.99);  % CLLL Reduction 
%         H_LR = CLLL(H);  % CLLL from FileExchange. Nearly same
%                          % performance as line above
%         T = H^-1 * H_LR;
    else     
        % No CLLL
        H_LR = H;
        T = eye(size(H));
    end

    T_inv = T^-1; 

    % addflops(flops_inv(length(T)));
    
%     if strcmp(modulation, 'QPSK')
%         d = 2 * sqrt(2 * signal_power);
%     elseif strcmp(modulation, '16-QAM')
%         d = sqrt(2/5 * var_s);
%     end
    
    S = zeros(N_t, L);
    for l = 1:L  % Multi-Branch loop
        if l == 1
            P_l = cnbo(H_LR);  % column-norm based ordering in H_LR % OK
        else
            P_l = psp(N_t, l, L);  % Pre_Stored Patterns % OK
        end
        
        H_LR_l = H_LR * P_l;  % Permute channel gain matrix for following 
                              % SIC
        % addflops(flops_mul(H_LR, P_l));
        
        z_hat = zeros(N_t,1);
        y_l_n = y;
                        
        for n = 1:N_t  % Loop over signal components
            
            if n == 1
                % Covariance matrix of z_l_n
                R_zz = 2*signal_power*(P_l'*(T_inv*T_inv')*P_l);
            else
                % Update 
                R_zz = R_zz(2:end, 2:end);  % How would you update matrices 
                % R_zz, T and P_l after SIC?
            end
                 
            % MMSE linear equalizer
            
            W_l_n = inv(ctranspose(H_LR_l)*H_LR_l+N*inv(R_zz)) * ...
                ctranspose(H_LR_l);  % Try this MMSE Filter

%             R_zy = R_zz * ctranspose(H_LR_l);
%             R_yy = H_LR_l * R_zz * ctranspose(H_LR_l) + N;
%             W_l_n = R_zy * inv(R_yy);
            
            z_l_n = W_l_n * y_l_n; % Output of MMSE detector. Detected 
                                   % signal component in reduced lattice 
                                   % space                                                
                                                
            % addflops(flops_mul(cols(W_l_n), rows(W_l_n), length(y_l_n)));

            % Shifting and Scaling operations 
            z_hat(n) = shifting_scaling(z_l_n(1), 1+1j, T_inv, P_l, n, ... 
                signal_power, modulation, true);

            y_l_n = y_l_n - H_LR_l(:,1) * z_hat(n);  % Subtract estimated 
                                                       % component from
                                                       % received signal to
                                                       % further reduce
                                                       % interference for
                                                       % detection in next
                                                       % iteration
            % addflops(2 * length(y_l_n));  
            
            H_LR_l = H_LR_l(:,2:end);  % Update channel gain matrix in LR 
                                       % domain by removing channel gains
                                       % for already estimated signal
                                       % components 
        end
        s_l = T * P_l * z_hat;  % Estimation of transmitted signal for 
                                % the l-th branch   
                                                                
        S(:,l) = s_l;
                                                                          
        % addflops(flops_mul(T, P_l) + flops_mul(N_t, N_t, 1));
                                     
    end
    Y = repmat(y,1,L);  % Create matrix with L columns of received signal y 
                        % to quickly calulcate the best estimate of s
    ml_arg = Y - H * S;
    [~, l_opt] = min(dot(ml_arg, ml_arg));  % ML decision % OK

%     addflops(flops_mul(rows(H), cols(H), cols(S)) + rows(Y) * cols(Y) ... 
%         + rows(ml_arg) * cols(ml_arg) + (rows(ml_arg)-1) * cols(ml_arg));
    
%     min_err = +Inf;
%     l_opt = 0;
%     for l = 1:L
%         err = norm(y - H*S(:,l))^2;
%         if err < min_err
%             min_err = err;
%             l_opt = l;
%         end
%     end
    
    s_estim = zeros(N_t, 1);
    
    % Quantization: Return valid constellation symbol
    for i = 1:N_t
        S_L = repmat(S(i, l_opt), size(constellation));
        if ~any(S_L == constellation)
            errs = abs(S_L-constellation).^2;
            [~, argmin] = min(errs(:));
            s_estim(i) = constellation(argmin);
        else
            s_estim(i) = S(i, l_opt);
        end    
    end
    
end 
