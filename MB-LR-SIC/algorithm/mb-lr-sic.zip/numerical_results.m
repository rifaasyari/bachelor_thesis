% BER performance of MB-LR-SIC algorithm
clear
clc

addpath('CLLL');

K = 2;  % number of active user

modulation = 'QPSK';

qpsk = [1+1j -1+1j -1-1j 1-1j];  % Equals 4-QAM constellation

runs = 10;
transmitted_symbols = 500;
snr_step = 5;
omit_zeros = false;

ml_detection = true;

if strcmp(modulation, '16-QAM')
    N_txi = 3;  % number of antennas for user i
    N_r = 6;  % number of total receive antennas 
    N_t = K*N_txi;  % total number of transmit antennas
    SNR_max = 20;
    decode = @decode_16QAM;
elseif strcmp(modulation, 'QPSK')
    N_txi = 2;  % number of antennas for user i
    N_r = 4;  % number of total receive antennas 
    N_t = K*N_txi;  % total number of transmit antennas
    SNR_max = 15;
    decode = @decode_qpsk;
else
    error('Invalid modulation %s', modulation);
end

BER_mblrsic = zeros(1, SNR_max/snr_step+1);
BER_mbsic = zeros(1, SNR_max/snr_step+1);  % MB-SIC detector
BER_ml = zeros(1, SNR_max/snr_step+1);

for SNR = 0:snr_step:SNR_max

    N = 1;  % Noise power
    var_s = N / N_t * 10^(SNR/10);  % Signal power
    
    if strcmp(modulation, '16-QAM')
        constellation = create_16_QAM(var_s);
        a = sqrt(var_s);
        
        disp(constellation);
        
    elseif strcmp(modulation, 'QPSK')
        % a = round(2 * sqrt(var_s)) / 2;
        a = sqrt(var_s);
        constellation = qpsk * a;  % QPSK modulation adapted to 
                                             % symbol power
        disp(constellation);
        
    else
        error('Invalid modulation %s', modulation);
    end
    
    BERs_mblrsic = zeros(1, runs);
    BERs_mbsic = zeros(1, runs);
    BERs_ml = zeros(1, runs);
    for i = 1:runs  % simulation runs
        H1 = 1/sqrt(2) * (randn(N_r, N_t) + 1j * randn(N_r, N_t)); 
        % channels for scenario 1
        
        BE_mblrsic = 0;  % Bit Errors for MB-LR-SIC detector
        BE_mbsic = 0;
        BE_ml = 0;  % Bit Errors for ML detector
        zero_symbols = 0;
        failed_symbols = 0;
        for k = 1:transmitted_symbols  % transmitted symbols
            
            s = constellation(randi([1,numel(constellation)], 1, N_t))';  
            % Generate signal vector
            
            % disp(s);
            
            n = (sqrt(N)*randn(N_r,1)).*exp(1j*2*pi*randn(N_r,1));  % CSCG 
            % noise vector
            
            y = H1 * s + n;
            
            s_mblrsic = mb_lr_sic(y,H1,a^2,N,modulation, constellation);
            s_mbsic = mb_lr_sic(y,H1,a^2,N,modulation,constellation,false);
            
            if (sum(real(s_mblrsic) == zeros(N_t,1)) || ...
                    sum(imag(s_mblrsic) == zeros(N_t,1))) && omit_zeros
                
                failed_symbols = failed_symbols+1;
            else
            
                zero_symbols = zero_symbols + ... 
                    sum(real(s_mblrsic) == zeros(N_t,1)) + ...
                    sum(imag(s_mblrsic) == zeros(N_t,1));    
                
                if ml_detection == true
                    s_ml = ml_mimo(y,H1,constellation);
                else
                    s_ml = zeros(N_t,1);
                end

                % Decode symbols
                b = decode(s, constellation);  % Transmitted bits
                b_mblrsic = decode(s_mblrsic, constellation);
                b_mbsic = decode(s_mbsic, constellation);
                b_ml = decode(s_ml, constellation);


%                 b = [real(s); imag(s)];
%                 b_mblrsic = [real(s_mblrsic); imag(s_mblrsic)];
%                 b_mbsic = [real(s_mbsic); imag(s_mbsic)];
%                 b_ml = [real(s_ml); imag(s_ml)];

                BE_mblrsic = BE_mblrsic + sum(b ~= b_mblrsic);  % Calc bit errors
                BE_mbsic = BE_mbsic + sum(b ~= b_mbsic);
                BE_ml = BE_ml + sum(b ~= b_ml);
            end
        end
        BERs_mblrsic(i) = BE_mblrsic / (transmitted_symbols * N_t * ... 
            log2(numel(constellation)) - failed_symbols);
        BERs_mbsic(i) = BE_mbsic / (transmitted_symbols * N_t * ... 
            log2(numel(constellation)) - failed_symbols);
        BERs_ml(i) = BE_ml / (transmitted_symbols * N_t * ... 
            log2(numel(constellation)) - failed_symbols);
        
        if ~omit_zeros
            fprintf('%d MB-LR-SIC, BER: %.4f, Zero symbols: %d/%d\n', ... 
                i, BERs_mblrsic(i), zero_symbols, 2*transmitted_symbols*N_t);
            fprintf('%d MB-SIC, BER: %.4f\n', i, BERs_mbsic(i));
            fprintf('%d ML, BER: %.4f\n', i, BERs_ml(i));
        else
            fprintf('%d, MB-LR-SIC, BER: %.5f, Failed symbols: %d/%d\n', ... 
                i, BERs_mblrsic(i), failed_symbols, 2*transmitted_symbols*N_t);
            fprintf('%d, ML, BER: %.5f\n', i, BERs_ml(i));
        end
        
    end
    BER_mblrsic(SNR/5+1) = mean(BERs_mblrsic);
    BER_mbsic(SNR/5+1) = mean(BERs_mbsic);
    BER_ml(SNR/5+1) = mean(BERs_ml);
end

figure
semilogy(0:5:SNR_max, BER_mblrsic, 'r-s', ... 
    'LineWidth', 2, ...
    'DisplayName', 'MB-LR-SIC');
hold on
semilogy(0:5:SNR_max, BER_mbsic, 'g-o', ... 
    'LineWidth', 2, ...
    'DisplayName', 'MB-SIC');
if ml_detection == true
    hold on
    semilogy(0:5:SNR_max, BER_ml, 'k-', ... 
        'LineWidth', 2, ...
        'DisplayName', 'ML');
end
title('MU-MIMO System, $N_{txi}$=2, $N_r$=4, L=4 Branches, K=2 users');
xlabel('SNR [dB]');
ylabel('BER');
ylim([0.5e-5, 1e0]);
grid on;
legend('show', 'Location', 'southwest');
